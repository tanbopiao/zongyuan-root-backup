#!/usr/bin/env python3
# 短剧生产台后端：真接火山方舟 API
# 启动: uvicorn main:app --host 0.0.0.0 --port 8000
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import os, time, requests, json, subprocess

OUT_DIR = "/home/user/Doubao/chats/38438491307070978/media_assets/output"
os.makedirs(OUT_DIR, exist_ok=True)

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# 火山方舟配置（从环境变量或前端传入）
ARK_BASE = "https://ark.cn-beijing.volces.com/api/v3"

class ProduceReq(BaseModel):
    api_key: str
    topic: str = ""
    script: str = ""
    style: str = "写实"

@app.post("/api/produce")
async def produce(req: ProduceReq):
    key = req.api_key
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}

    # 1. 文本：生成/润色剧本
    script_prompt = req.script or f"把这个题材写成30秒短剧分镜：{req.topic}"
    text_r = requests.post(f"{ARK_BASE}/chat/completions", headers=headers, json={
        "model": "doubao-pro", "messages": [{"role":"user","content":script_prompt}]
    }, timeout=30)
    script_out = text_r.json().get("choices",[{}])[0].get("message",{}).get("content","(剧本生成失败)")

    return {"status":"done","script":script_out,"msg":"剧本已生成"}

@app.post("/api/image")
async def gen_image(req: ProduceReq):
    """Seedream 文生图（关键帧）"""
    r = requests.post(f"{ARK_BASE}/images/generations", headers={"Authorization":f"Bearer {req.api_key}"}, json={
        "model":"doubao-seedream","prompt":req.script or req.topic,"size":"1024x1024"
    }, timeout=60)
    return {"status":"done","images":r.json().get("data",[])}

@app.post("/api/video")
async def gen_video(req: ProduceReq):
    """Seedance 文生视频"""
    r = requests.post(f"{ARK_BASE}/video/generations", headers={"Authorization":f"Bearer {req.api_key}"}, json={
        "model":"doubao-seedance","prompt":req.script or req.topic
    }, timeout=120)
    return {"status":"done","video":r.json()}

def compose_final(clips, name="final.mp4"):
    """ffmpeg合成：把视频片段拼接成成片（前置闭环能力）"""
    listf = OUT_DIR + "/_list.txt"
    open(listf,"w").write("\n".join(f"file '{c}'" for c in clips))
    out = OUT_DIR + "/" + name
    subprocess.run(["ffmpeg","-y","-f","concat","-safe","0","-i",listf,"-c","copy",out],check=True)
    return out

@app.get("/")
def home():
    return {"msg":"drama-studio real backend running"}
